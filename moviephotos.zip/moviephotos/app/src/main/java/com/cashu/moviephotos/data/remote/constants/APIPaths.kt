/*
 * Copyright (c) 2021.
 * Created by Ahmed Awad
 * ahmed.mmawad@hotmail.com
 */

package com.cashu.moviephotos.data.remote.constants

class APIPaths {

    companion object {
        const val SERVICES_REST = "services/rest"
    }


    /*
 https://www.flickr.com/services/rest/?method=flickr.photos.search
 &format=json&nojsoncallback=50&text=Color
 &page=1&per_page=20&api_key=d17378e37e555ebef55ab86c4180e8dc
  */
}
